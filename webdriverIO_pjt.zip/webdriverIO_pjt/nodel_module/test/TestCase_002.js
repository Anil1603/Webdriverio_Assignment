const loginTestdata = require("../testdata/logindata");
const productDataObject = require("../testdata/productsTestdata"); 

describe("This is my Second TestCase in Swag Labs",function(){
    
    it('should let you log in', function () { 
    browser.url('https://www.saucedemo.com/');
     browser.maximizeWindow(); 
     brower.pause(5000); 
     browser.setValue('input[id="user-name"]', loginTestdata.username);
     browser.setValue('input[id="password"]', loginTestdata.password);
      //browser.click();
    let login_bt = $('input[id="login-button"]'); 
    login_bt.click(); 
    
    const title = browser.getTitle(); 
    assert.strictEqual(title, 'Swag Labs'); //verifying page Title. 
    
    let totalProducts = $$('div[class="inventory_item_name"]');
     totalProducts.forEach(element => { 
         console.log(element.getText()) //prints list of products. 
        });
        
        let product_Title = $$('div[class="inventory_item_name"]');
         product_Title.forEach(element => { 
             assert.strictEqual(element.getText(), productDataObject[1]['name']); //verifying product Title.
             }); 
         
             let product_desc = $$('div[class="inventory_item_desc"]');
          product_desc.forEach(element => { 
              assert.strictEqual(element.getText(), productDataObject[1]['description']); //verifying product descprition.
             });
             
             let product_price = $$('div[class="inventory_item_price"]"]'); 
             product_price.forEach(element => {
                  assert.strictEqual(element.getText(), productDataObject[1]['price']); //verifying product Price. 
                });
             })
             })