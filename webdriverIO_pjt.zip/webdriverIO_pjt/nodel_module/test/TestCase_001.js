describe("This is my First TestCase in Swag Labs", function () { 
    it('should let you log in', function () { 
    browser.url('https://www.saucedemo.com/'); 
    browser.maximizeWindow(); brower.pause(5000); 
    browser.setValue('input[id="user-name"]', 'standard_user'); 
    browser.setValue('input[id="password"]', 'secret_sauce'); 
    //browser.click(); 
    let login_bt = $('input[id="login-button"]'); //clicking login button
    login_bt.click(); 
    
    const title = browser.getTitle();
     assert.strictEqual(title, 'Swag Labs'); //verifying page Title.
     
     // Cart value printing

     const count_beforeAddindProd = $('a[class="shopping_cart_link"]').getText(); 
     assert.strictEqual(count_beforeAddindProd, ''); //verifying cart has 0 items.
     
     
     let totalProducts = $$('div[class="inventory_item_name"]');
      totalProducts.forEach(element => { 
      console.log(element.getText()) //prints list of products. 
    });



       let AddToCart_btns = $$('button[class="btn btn_primary btn_small btn_inventory"]');
        AddToCart_btns.forEach(Addcartbtn => { 
        console.log(Addcartbtn.click()) //Clicks Add to Cart button for all products
     }); 
        
        const count_afterAddindProd = $('a[class="shopping_cart_link"]').getText();
         assert.strictEqual(count_afterAddindProd, '6'); //verifying cart has 6 items. 
         
         let RemovefromCart_btns = $$('button[class="btn btn_primary btn_small btn_inventory"]'); 
         AddToCart_btns.forEach(Rmcartbtn => { 
        console.log(Rmcartbtn.click()) //Clicks remove fron Cart button for all products 
    }); 
    
    const count_afterRemovingall = $('a[class="shopping_cart_link"]').getText();
     assert.strictEqual(count_afterRemovingall, ''); //verifying cart has 0 items. 
    })
 })
